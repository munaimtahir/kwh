# Contributing
- Use feature branches and PRs.
- Keep tasks updated in `TASKS.md`.
- Write/maintain tests; keep docs current.
