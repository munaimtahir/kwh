# Setup.md
## Prereqs
- Android Studio Hedgehog+
- Android SDK 34; Gradle wrapper

## Build
```bash
./gradlew assembleDebug
./gradlew test
```

## Run
- Connect a device/emulator; hit Run in Android Studio.
