# QA Checklist
- [x] Install/launch on API 26, 30, 34. (Pixel 6 / Pixel 4a / Nexus 5X emulator)
- [x] First-run empty state shows.
- [x] Meter create → reading add → latest visible.
- [x] Reminder fires at next scheduled time; snooze action works (M4).
- [x] CSV export opens share sheet; file readable (M3).
